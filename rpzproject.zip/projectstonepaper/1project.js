let userScore=0;
let compScore=0;

const userScoreMsg = document.querySelector("#user-score");
const compScoreMsg = document.querySelector("#comp-score");
const choices= document.querySelectorAll(".choice");
const msg = document.querySelector("#msg");

//COMPUTER CHOICE FUNCTION
const getCompChoice=()=>{
   const options=['rock','paper','scissors'];
   const ranIdx= Math.floor(Math.random()*3);
    /*math class have a random method which produces random float numbers it generates number (which is multiplied-1)
    and then to remove the part after decimal we use floor. */
return options[ranIdx];
}


//DRAW GAME FUNCTION
const drawGame=()=>{
    msg.innerText="Game Was Draw";
    msg.style.backgroundColor="#18042b";
}

//SHOW WINNER FUNCTION
const showWinner = (userWin,userChoice,compChoice)=>{
    if(userWin){
        userScore++;
userScoreMsg.innerText=userScore;
        msg.innerText=`You Win!! your choice ${userChoice} beats bot's Choice ${compChoice}`;
        msg.style.backgroundColor="green";    
    }
    else{
        compScore++;
        compScoreMsg.innerText=compScore;
        msg.innerText=`You Lost!! his choice ${compChoice} beats your Choice ${userChoice}`;
        msg.style.backgroundColor="red";   
    };
}


//MAIN FUNCTION WHICH RUNS THE GAME
const playGame =(userChoice)=>{
    console.log('userChoice',userChoice);
//computer choice generator;
 const compChoice =getCompChoice();
 console.log('compChoice',compChoice);

 if(userChoice===compChoice){
    //draw game
    drawGame();
 }
 else{
    let userWin = true;
    if(userChoice==="rock"){
        //scissors,paper
        userWin=compChoice==="paper" ? false : true;
    }
    else if(userChoice==="paper"){
        //scissors,rock
        userWin = compChoice ==="scissors" ? false : true;
    }
    else{
        //rock,paper
        userWin = compChoice==="rock" ? false : true;
    }
    showWinner(userWin,userChoice,compChoice);
 } 
};

//TO SELECT THE CHOICE AND ADD EVENT LISTNERS TO MY IMAGES
choices.forEach((choice) =>{
choice.addEventListener("click",()=>{
    const userChoice = choice.getAttribute("id");
playGame(userChoice);
});
});